// Based on the file: PitchMarking.m
// The second file called in run.m of any importance

#define FRAME_SIZE 2048
#define FRAME_RATE 512

int pitchMarking(char *input, int pitchContour[]){
    int v[FRAME_SIZE];


}
