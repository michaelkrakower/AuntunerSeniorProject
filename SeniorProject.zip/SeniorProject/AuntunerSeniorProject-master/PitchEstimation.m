%--------------------------------------------------------------------------
% pitch estimation using autocorrelation method
%--------------------------------------------------------------------------
function PitchContour = PitchEstimation(x, fs)
% Init parameters
FrameSize = 2048; %number of sample in 30 ms
FrameRate = 512; %number of sample in 10 ms
WaveLength = length(x);
NumberOfFrames = floor((WaveLength - FrameSize) / FrameRate)+2;
FramePitch = zeros(NumberOfFrames+2, 1);

% Calculate pitch for each frame
Range = 1 : FrameSize;
for Count = 2 : NumberOfFrames
    FramePitch(Count) = PitchDetection(x(Range), fs); % pitch for frame
    Range = Range + FrameRate; % Move to next frame
end

% Using median filter for Pos-processing
FramePitch = medfilt1(FramePitch,5);

% calculate pitch contour
PitchContour = zeros(WaveLength, 1);
for i = 1 : WaveLength-1
    if floor(i / FrameRate)== 0
        PitchContour(i) = FramePitch(floor(i / FrameRate)+1);
    else
        PitchContour(i) = FramePitch(floor(i / FrameRate));
    end
end