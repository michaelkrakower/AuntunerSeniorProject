// Converted form of pitchEstimation.m
// The first file called in run.m. Highest level of c code in PSOLA algorithm
// Header to be done later

#include <stdint.h>
#define FRAME_SIZE 2048
#define FRAME_RATE 512

int pitchEstiation(char *input, char *output, int32_t fs){
    // After initial analysis -> char *needstobedone = input[512];
    int i;
    int *framePitch;

    for(i=0 ; i < FRAME_SIZE/FRAME_RATE ; i++){
        framePitch[i] = pitchDetection(input[i*FRAME_RATE]);
    }

    int pitchContour[FRAME_SIZE];

    for (i=0 ; i < FRAME_SIZE ; i++) {
        int value = i/FRAME_RATE;
        pitchContour[i] = framePitch[value];
    }
}

// DONE ISH
