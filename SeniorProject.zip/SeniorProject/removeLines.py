import re

f = open('audioio.c')
fnew= open('audioionew.c', 'w')
lines=f.readlines()

i=0
for line in lines:
    line = line[5:]
    print(line)
    fnew.write(line)
