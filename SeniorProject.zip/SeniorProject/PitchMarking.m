// Based on the file: PitchMarking.m
