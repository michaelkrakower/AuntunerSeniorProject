//
//  PSOLA.c
//
//
//  Created by Michael Krakower on 6/9/16.
//
//

#include "PSOLA.h"
#include <stdbool.h>

// NOTE: Use the paper below for reference
// http://www.ece.ucsb.edu/Faculty/Rabiner/ece259/Reprints/110_autocorrelation%20pitch.pdf

// GLOBAL VARIABLES
double frame[300];

// END OF GLOBAL VARIABLES

/* Autocorrelation method
  Takes in frame extracted from portaudio library and autocorrelates to find pitch period
  returns Period length
 */
double autoCorr(){
    int N = sizeof(frame); // Empty array of ints the size of the frame
    double lagOutput[N/2]; // Not sure what I was thinking here, figure it out
    double rx = 0; // Delay applied to autocorrelation
    int i,j;
    for(i = 0 ; i < N/2 ; i++){ // Nested for loops...why?
        rx = rx + frame[i] * frame[i];
        }
        rx = rx * (1/N);
        lagOutput[i] = rx;
        rx = 0;

    for (j=1 ; j < N/2-2 ; j++){
        if (lagOutput[j] > lagOutput[j-1] && lagOutput[j] > lagOutput[j+1]){
            // Is peak = true
        }
    }
}

double variance(){
    double var;
    int N = sizeof(frame); // Empty array of ints the size of the frame
    int i;
    for (i=0 ; i<N ; i++){
        var = var + (pow((frame[i]),2.0) / N);
    }

    return(var);
}



bool isPeak(int i){ // i is the location of value being checked for peak
    bool ispeak = false;
    if (frame[i-1] < frame[i] && frame[i+1] < frame[i]){
        ispeak = true;
    }
    return(ispeak);
}

void main(){

    double inputArray = {0.5, 0.75, 1, 0.75, 0.5, 0.25, 0, -0.25, -0.5, -0.75, -1, -0.75, -0.5};

    autoCorr(inputArray);
}


/*
    BELOW IS A CONVERSION OF PSOLA.m
*/

/*
   Input Parameters:
        input: The array of input values for any given frame
        fs: The sampling frequency (Will always be 48,000)
        anaPm: Analysis pitch marks. I need to find out exactly what this is before I proceed.
        timeScale: ?? Could be output variable
        pitchScale: ?? Could be output variable
*/

double PSOLA(double input[], int fs, double anaPm[], int timeScale, int pitchScale){
    // Take pitch for this frame
    // Identify closest pitch in even tempered system
    // Adjust frame to even desired pitch
    double output[];
    int i,j;


    int length = sizeof(anaPm);
    if (length <= 3){
        output = input;
        return;
    }

    double pitchPeriod[sizeof(input)];
    for (i=1 ; i < length ; i++){
        // Unsure about this loop, come back to it, MATLAB code below
        /*
            pitchPeriod(anaPm(i-1):anaPm(i)-1) = anaPm(i)-anaPm(i-1);
        */
    }
    /*
    pitchPeriod(1:anaPm(1)-1) = pitchPeriod(anaPm(1));
    pitchPeriod(anaPm(len):length(input)) = pitchPeriod(anaPm(len) - 1);
    */
    double synPm[];
    // To be continued
}

// Subfunctions within PSOLA.m
double selectCorrectPos(int i){
    if (i == 1){
        i = 2;
    } else if (i>= (sizeof(anaPm)+1)){
        i = length(anaPm) - 2;
    }
    return i;
}

double addTogether(int y[], int x[], int t){
    int length = sizeof(x);
    int max = t + length - 1;
    int range = max -  t;
    int maxLen;

    if (max > maxLen){
        maxLen = max;
    }

    length = sizeof(y);
    // To be continued...figure out how to accomidate size() v. length()
}

double resampling(int x[], double scale){
    int m = sizeof(x);

}
