// Converted IncreaseMarking.m and FindPeakCandidates.m

// Add header later

int IncreaseMarking(double x[], int p[], int fs, int m){
    int length = sizeof(x);
    int count = 0;
    int ca[];
    int LeftThr = 0;
    int i=0;

    while (i < length){

    }
}

int FindPeakCandidates(double x[], int maxCandidatesNum, int offset){
    int length = sizeof(x);
    // Circle shift stuff
    int PeakIndices;

    //Other stuff before while to be added later

}

int find_max(double x[]){
    int max=0;
    int length = sizeof(x);
    int i;
    for(i=0 ; i < length ; i++){
        if(x[i] > x[max]){
            max = i;
        }
    }
    return max;
}
